jQuery.noConflict()(function($) {

});