jQuery.noConflict()(function($) {
    jQuery('.pixad-body-filter li').on('click', function () {

        if($(this).hasClass('active')){
            jQuery(this).removeClass('active');
        } else {
            jQuery('.pixad-body-filter li').removeClass('active');
            jQuery(this).addClass('active');
        }

        if($('.pixad-body-filter li').hasClass('active')){

        }
        var body = $(this).data('val');
        var models =  $(this).siblings('.models').val();
        var count =  $(this).siblings('.count').val();
        //jQuery('.fl-archive-sorting-contain').removeClass('active');
        //jQuery(this).addClass('active');

        showAjaxLoader();
        if($('#pixad-listing').length > 0){
            var data = {
                action: 'templines_change_query',
                models: models,
                body: body,
                count: count
            };
            jQuery.post( templines_ajax.url, data, function(response) {
                console.log(response.data);
                jQuery('#pixad-listing').html(response.data);
                hideAjaxLoader();
            });
        }
    });


    function showAjaxLoader(){
        jQuery('#pixad-listing').addClass('ajax-loading');
    }
    function hideAjaxLoader(){
        jQuery('#pixad-listing').removeClass('ajax-loading');
    }
});