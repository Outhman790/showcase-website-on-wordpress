<?php
namespace TemplinesElementorControls;
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class TemplinesElementor_Custom_Controls {

	public function includes() {
		require_once(TEMPLINES_HELPER_CORE_PLUGIN_PATH. '/elementor/custom-controle/image-selector/image-selector-control.php');
	}

	public function register_controls() {
		$this->includes();
		$controls_manager = \Elementor\Plugin::$instance->controls_manager;
		$controls_manager->register_control(\Elementor\CustomControl\TemplinesImageSelector_Control::ImageSelector, new \Elementor\CustomControl\TemplinesImageSelector_Control());
	}

	public function __construct() {
		add_action('elementor/controls/controls_registered', [$this, 'register_controls']);
	}

}
new TemplinesElementor_Custom_Controls();