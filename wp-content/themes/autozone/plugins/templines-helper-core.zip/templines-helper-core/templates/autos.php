<?php
$templines_result ='';
global $post, $PIXAD_Autos;
$Settings = new PIXAD_Settings();
$settings = $Settings->getSettings( 'WP_OPTIONS', '_pixad_autos_settings', true );
$validate = $Settings->getSettings( 'WP_OPTIONS', '_pixad_autos_validation', true ); // Get validation settings
$showInSidebar = pixad::getsideviewfields($validate);
$validate = pixad::validation( $validate ); // Fix undefined index notice

while ( $autos->have_posts() ) : $autos->the_post();
    $templines_result .= '<div class="col-md-4">';
    $templines_result .= '<div class="slider-grid__inner slider-grid__inner_mod-b">';
    $templines_result .= '<div class="card__img">';
                if( has_post_thumbnail() ):
                    $templines_result .= '<a href="' . get_the_permalink() . '">';
                        $templines_result .= get_the_post_thumbnail(get_the_ID(), 'autozone-auto-single_crop', array('class' => 'img-responsive'));
                    $templines_result .= '</a>';
                else:
                    $templines_result .= '<img class="no-image" src="' . PIXAD_AUTO_URI . 'assets/img/no_image.jpg" alt="no-image">';
                endif;

                if( get_post_meta(get_the_ID(), 'pixad_auto_featured_text', true) ):
                    $templines_result .= '<span class="card__wrap-label"><span class="card__label">' . get_post_meta( get_the_ID(), 'pixad_auto_featured_text', true ) . '</span></span>';
                endif;

                if( $validate['auto-price_show'] && $PIXAD_Autos->get_meta('_auto_price') ):

                    $custom_price_catalog = get_post_meta( $post->ID, 'custom_price_catalog', 1 );
                    $price_catalog = $custom_price_catalog ? $custom_price_catalog : $PIXAD_Autos->get_price();
                    //$price_catalog = is_numeric($PIXAD_Autos->get_meta('_auto_price')) || $PIXAD_Autos->get_meta('_auto_price') == '' ? $PIXAD_Autos->get_price() : $auto_translate[$PIXAD_Autos->get_price()];

                    $templines_result .= '<span class="slider-grid__price_wrap"><span class="slider-grid__price"><span>' .wp_kses_post($price_catalog).'</span></span></span>';
                endif;
              //  $templines_result .= do_action( 'autozone_autos_single_auto_img', $post );

                if( is_user_logged_in() ):

                    $author_ID = get_post_field( 'post_author', get_the_ID() );
                    $user = get_user_by('ID', $author_ID);
                    if( $author_ID == get_current_user_id()){
                        $templines_result .= '<a class="tm-autos-top-edit-button" href="' . esc_url(get_site_url().'/members/') . $user->user_login . '/add_autos?auto_id=' . get_the_ID().'"><span>' . __('Edit', 'templines-helper-core') .'</span></a>';
                    }
                endif;
            $templines_result .= '</div>';
            $templines_result .= '<div class="tmpl-gray-footer">';
                $templines_result .= '<a class="tmpl-slider-grid__name" href="' . get_the_permalink() .'">'. wp_kses_post(get_the_title()) .'</a>';
                if(!empty($post_rating)):
                    $templines_result .= '<div class="star-rating"><span style="width:' . esc_html( array_sum($post_rating)/count($post_rating) * 20 ) . '%"></span></div>';
                endif;
                $templines_result .= '<ul class="tmpl-slider-grid__info list-unstyled">';
                    foreach ($showInSidebar as $id => $sideAttribute):
                        $id='_'.$id;
                        $id = str_replace('-', '_', $id);

                        if( $PIXAD_Autos->get_meta($id) ):
                            $templines_result .= '<li><i class="' . esc_html($sideAttribute['icon']) .'"></i>';

                                $val_attr =  $PIXAD_Autos->get_meta($id);
                                if(!empty($auto_translate[$val_attr])  ){
                                    $templines_result .= esc_html($auto_translate[$val_attr]);
                                }else{
                                    $templines_result .= esc_html($PIXAD_Autos->get_meta($id));
                                }

                            $templines_result .= '</li>';
                        endif;
                    endforeach;
    $templines_result .= '</ul>';
    $templines_result .= '</div>';

        $templines_result .= '</div>';
    $templines_result .= '</div>';
endwhile;