<?php

add_action( 'wp_enqueue_scripts', 'tm_reviews_ajax_data', 99 );
function tm_reviews_ajax_data(){
    wp_enqueue_script   ('templines_ajax', TEMPLINES_HELPER_CORE_PLUGIN_URL .  '/assets/js/templines-ajax.js', '', '', true);
    wp_localize_script('templines_ajax', 'templines_ajax',
        array(
            'url' => admin_url('admin-ajax.php')
        )
    );
}

add_action('wp_ajax_templines_change_query', 'templines_change_query_callback');
add_action('wp_ajax_nopriv_templines_change_query', 'templines_change_query_callback');
function templines_change_query_callback() {

    $models = explode("|", $_REQUEST['models']);
    $models_term =  array(
        'taxonomy' => 'auto-model',
        'field' => 'slug',
        'terms' => $models
    );

    if($_REQUEST['body'] == 'all' or $_REQUEST['body'] == ''){
        $body_term = '';
    } else {
        $body_term =  array(
            'taxonomy' => 'auto-body',
            'field' => 'slug',
            'terms' => $_REQUEST['body']
        );
    }


    $args = array(
        'post_type' => 'pixad-autos',
        'post_status'    => 'publish',
        'tax_query' => array(
            $models_term,
            $body_term
        ),
        'posts_per_page' => $_REQUEST['count']
    );

    $autos = new WP_Query($args);


    include( TEMPLINES_HELPER_CORE_PLUGIN_PATH . 'templates/autos.php' );

  ///  wp_send_json_success($autos);
    wp_send_json_success($templines_result);

    wp_die();
}

