<?php
/**
 * Plugin Update Checker Library 4.9
 * http://w-shadow.com/
 *
 * Copyright 2020 Janis Elsts
 * Released under the MIT license. See license.txt for details.
 */

require dirname(__FILE__) . '/load-v4p9.php';